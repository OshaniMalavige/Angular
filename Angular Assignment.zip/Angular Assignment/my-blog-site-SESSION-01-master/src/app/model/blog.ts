export interface Blog {
  id: number;
  title: string;
  date: Date;
  imgUrl: string;
  description: string;
}
