export interface Blog {
  id: number;
  title: string;
  date: Date;
  rating:number;
  imgUrl: string;
  description: string;
}
